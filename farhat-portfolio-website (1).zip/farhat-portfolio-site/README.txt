FARHAT PORTFOLIO WEBSITE - README
==================================

FILES:
- index.html  -> your complete website (open this in any browser, or upload as-is to any hosting)

HOW TO EDIT:
- Open index.html in any text/code editor (VS Code recommended).
- All CSS is inside the <style> tag at the top.
- All content is inside the <body>, written in plain readable HTML.

THINGS YOU STILL NEED TO FILL IN (search for these in index.html):
- [Your Email]      -> mailto links in Contact section
- [Your WhatsApp]   -> wa.me link in Contact section
- [Your LinkedIn]   -> Contact section link
- [Your GitHub]     -> Contact section link
- [Your Fiverr]     -> Contact section link
- [Your Upwork]     -> Contact section link

CONTACT FORM (how clients actually message you - no database needed):
- The "Start a Project" button reveals a real contact form (name, email, message).
- It's wired for NETLIFY FORMS: free, zero backend, zero database.
  1. Deploy this site on Netlify (see hosting steps below).
  2. Netlify auto-detects the form on deploy because it has data-netlify="true".
  3. Go to your Netlify site dashboard -> Forms tab -> every submission appears there.
  4. Site settings -> Forms -> Form notifications -> add your email to get notified
     instantly when someone submits (Netlify emails you the message directly).
  5. No sign-up flow for your visitors, no database, no code needed on your side.

- IF YOU HOST SOMEWHERE OTHER THAN NETLIFY (e.g. GitHub Pages, Vercel):
  Netlify Forms won't work there. Easiest free alternative: Formspree.io
  1. Create a free account at formspree.io, create a new form, copy your form endpoint
     (looks like https://formspree.io/f/xxxxxxxx).
  2. In index.html, find: <form id="projectForm" ... data-netlify="true" ...>
  3. Replace the opening <form> tag with:
     <form id="projectForm" class="contact-form" action="https://formspree.io/f/xxxxxxxx" method="POST">
  4. Remove the data-netlify, netlify-honeypot, and the hidden form-name input line
     (Formspree doesn't need them).
  5. Done - submissions arrive at your Formspree account and get emailed to you.

HOW TO HOST IT LIVE (free options):
1. Netlify Drop -> netlify.com/drop -> drag this whole folder in -> live in seconds,
   AND your contact form works immediately (recommended - simplest path).
2. GitHub Pages -> push this folder to a GitHub repo -> enable Pages in repo settings
   (pair with Formspree for the contact form, see above).
3. Vercel -> vercel.com -> import project / drag-and-drop deploy
   (pair with Formspree for the contact form, see above).

NOTES:
- Your profile photo is embedded directly inside index.html (as base64) - no separate
  image file to lose or break links to.
- Single self-contained file: no build step, no dependencies to install.
- Fonts (Space Grotesk, Inter) load from Google Fonts automatically when opened online.
